//
//  BlipChat.h
//  BlipChat
//
//  Created by Curupira on 05/05/17.
//  Copyright © 2017 Curupira. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BlipChat.
FOUNDATION_EXPORT double BlipChatVersionNumber;

//! Project version string for BlipChat.
FOUNDATION_EXPORT const unsigned char BlipChatVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BlipChat/PublicHeader.h>


