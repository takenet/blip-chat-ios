# Change Log
All notable changes to this project will be documented in this file

## 0.0.20 - 2017-04-12
### Changed
- Add this CHANGELOG file
- Add inline documentation

## 0.0.20 - 2017-04-12
### Changed
- Create auth model