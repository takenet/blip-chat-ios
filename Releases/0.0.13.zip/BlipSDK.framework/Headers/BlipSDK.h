//
//  BlipSDK.h
//  BlipSDK
//
//  Created by Curupira on 09/01/17.
//  Copyright © 2017 Curupira. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BlipSDK.
FOUNDATION_EXPORT double BlipSDKVersionNumber;

//! Project version string for BlipSDK.
FOUNDATION_EXPORT const unsigned char BlipSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BlipSDK/PublicHeader.h>


