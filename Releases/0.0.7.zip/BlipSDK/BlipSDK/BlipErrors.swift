//
//  IllegalArgument.swift
//  BlipSDK
//
//  Created by Curupira on 10/01/17.
//  Copyright © 2017 Curupira. All rights reserved.
//

import Foundation
enum BlipErrors: Error {
    case illegalArgument
    case fileNotFound
}
