//
//  BlipWebViewBuilder.swift
//  BlipSDK
//
//  Created by Curupira on 10/01/17.
//  Copyright © 2017 Curupira. All rights reserved.
//

import Foundation
class BlipWebViewBuilder{
    
    private var cookiesField: [String] = []
    private var webview: UIWebView
    
    public init(webview: UIWebView){
        self.webview = webview
    }
    
    public func build() -> UIWebView{
        let url = NSURL(string: Constants.BLIP_SDK_URL)
        
        let storage = HTTPCookieStorage.shared
        var cookieString = ""
        for field in cookiesField {
            cookieString += (field + ", ")
        }
        
        let cookieHeaderField = ["Set-Cookie": cookieString]
        
        let cookies = HTTPCookie.cookies(withResponseHeaderFields: cookieHeaderField, for: url as! URL)
        storage.setCookies(cookies, for: url as URL?, mainDocumentURL: url as URL?)

        return webview
    }
    
    public func withCustomerCredentials() -> BlipWebViewBuilder{
        let prefereces = UserDefaults.standard
        let blipSdkUId = prefereces.string(forKey: Constants.USER_IDENTIFIER_KEY) ?? UUID().uuidString + "_" + Bundle.main.bundleIdentifier!
        let blipSdkUPw = prefereces.string(forKey: Constants.USER_PASSWORD_KEY) ?? UUID().uuidString.toBase64()
        
        prefereces.set(blipSdkUId, forKey: Constants.USER_IDENTIFIER_KEY)
        prefereces.set(blipSdkUPw, forKey: Constants.USER_PASSWORD_KEY)
        
        cookiesField += [Constants.USER_IDENTIFIER_KEY + "=" + blipSdkUId]
        cookiesField += [Constants.USER_PASSWORD_KEY + "=" + blipSdkUPw]
        return self
    }
    
    public func withRecipient(recipientIdentifier: String!) throws -> BlipWebViewBuilder {
        
        if(recipientIdentifier.isEmpty) {
            throw BlipErrors.illegalArgument
        }
        cookiesField += [ Constants.TO_RECIPIENT_IDENTIFIER + "=" + recipientIdentifier + "@" + Constants.BLIP_DEFAULT_DOMAIN]
        return self
    }
    
    public func withCacheEnabled() -> BlipWebViewBuilder{
        return self
    }
    
    public func withCustomerAccount() -> BlipWebViewBuilder{
        let prefereces = UserDefaults.standard
        
        if let userName = prefereces.string(forKey: Constants.USER_NAME_KEY){
            cookiesField += [Constants.USER_NAME_KEY + "=" + userName]
        }
        
        if let userPhotoUri = prefereces.string(forKey: Constants.USER_PHOTO_URI_KEY){
            cookiesField += [Constants.USER_PHOTO_URI_KEY + "=" + userPhotoUri]
        }
        
        if let userExternalId = prefereces.string(forKey: Constants.USER_EXTERNAL_ID_KEY){
            cookiesField += [Constants.USER_EXTERNAL_ID_KEY + "=" + userExternalId]
        }
        
        if let userExtras = prefereces.string(forKey: Constants.USER_EXTRAS_KEY){
            cookiesField += [Constants.USER_EXTRAS_KEY + "=" + userExtras]
        }

        return self
    }

    public func withOwnerCredentials() throws -> BlipWebViewBuilder{
        
        let credentials  = try readPropertyList()
        
        let blipSdkOId = credentials.identifier
        let blipSdkOPw = credentials.password
        
        cookiesField += [Constants.OWNER_IDENTIFIER_KEY + "=" + blipSdkOId]
        cookiesField += [Constants.OWNER_PASSWORD_KEY + "=" + blipSdkOPw]
    
        return self;
    }
    
    func readPropertyList() throws -> (identifier: String, password: String){
        var propertyListForamt =  PropertyListSerialization.PropertyListFormat.xml //Format of the Property List.
        var plistData: [String: AnyObject] = [:] //Our data
        let plistPath: String? = Bundle.main.path(forResource: "blip", ofType: "plist") //the path of the data
        if plistPath == nil {
            throw BlipErrors.fileNotFound
        }
        let plistXML = FileManager.default.contents(atPath: plistPath!)!
        
        let identifier:String!
        let password:String!
        plistData = try PropertyListSerialization.propertyList(from: plistXML, options: .mutableContainersAndLeaves, format: &propertyListForamt) as! [String:AnyObject]
        identifier = plistData[Constants.OWNER_IDENTIFIER_PROPERTY_KEY] as! String
        password = plistData[Constants.OWNER_PASSWORD_PROPERTY_KEY] as! String
            
        
        return (identifier, password)
    }
}
