//
//  BlipClient.swift
//  BlipSDK
//
//  Created by Curupira on 09/01/17.
//  Copyright © 2017 Curupira. All rights reserved.
//

import Foundation

@objc public class BlipClient : NSObject{
    
    public static func openBlipThread(myView: UIViewController, recipientIdentifier: String!){
        let threadViewController:ThreadViewController = ThreadViewController()
        threadViewController.blipSdkToId = recipientIdentifier
        
        myView.present(threadViewController, animated: true, completion: nil)
    }
    
    
    public static func setUserAccount(userAccount:BlipAccount){
        let prefereces = UserDefaults.standard
        prefereces.set(userAccount.name, forKey: Constants.USER_NAME_KEY)
        prefereces.set(userAccount.photoUri, forKey: Constants.USER_PHOTO_URI_KEY)
        prefereces.set(userAccount.externalId, forKey: Constants.USER_EXTERNAL_ID_KEY)
    }
}
