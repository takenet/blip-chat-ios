//
//  BlipAccount.swift
//  BlipSDK
//
//  Created by Curupira on 09/01/17.
//  Copyright © 2017 Curupira. All rights reserved.
//

import Foundation
@objc public class BlipAccount : NSObject{
    
    public override init(){
    }
    
    public var name:String = ""
    public var photoUri:String = ""
    public var externalId:String = ""
    
}
