//
//  ThreadViewController.swift
//  BlipSDK
//
//  Created by Curupira on 10/01/17.
//  Copyright © 2017 Curupira. All rights reserved.
//

import UIKit

class ThreadViewController: UIViewController{
    
    var webView : UIWebView!
    var blipSdkToId : String!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.webView = UIWebView(frame: CGRect(x: 0, y: 20, width: view.frame.width, height: view.frame.height-20))
        self.webView.scrollView.bounces = false
    }
    
    override func viewDidAppear(_ animated: Bool) {
        do{
            webView = try BlipWebViewBuilder(webview: webView)
                .withCustomerAccount()
                .withCustomerCredentials()
                .withOwnerCredentials()
                .withRecipient(recipientIdentifier: blipSdkToId)
                .build()
        }catch {
            print("Error to build a Blip webview: " + error.localizedDescription)
            dismiss(animated: true, completion: nil)
            return
        }
        
        self.view.addSubview(self.webView!)
        
        let url = NSURL(string: Constants.BLIP_SDK_URL)
        let request = NSURLRequest(url: url! as URL)
        
        webView.loadRequest(request as URLRequest)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}
