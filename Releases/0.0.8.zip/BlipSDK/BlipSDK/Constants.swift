//
//  Constants.swift
//  BlipSDK
//
//  Created by Curupira on 10/01/17.
//  Copyright © 2017 Curupira. All rights reserved.
//

import Foundation

public class Constants{
    
    public static let BLIP_SDK_URL = "https://hmg-blip-sdk.azurewebsites.net"
    public static let BLIP_DEFAULT_DOMAIN = "msging.net"
    
    //Keys
    public static let PREFERENCES_KEY = "BlipSDK"
    public static let USER_IDENTIFIER_KEY = "blipSdkUId"
    public static let USER_PASSWORD_KEY = "blipSdkUPw"
    public static let TO_RECIPIENT_IDENTIFIER = "blipSdkToId"
    
    public static let OWNER_IDENTIFIER_KEY = "blipSdkOId"
    public static let OWNER_PASSWORD_KEY = "blipSdkOPw"
    
    public static let OWNER_IDENTIFIER_PROPERTY_KEY = "blipsdk.ownerIdentity"
    public static let OWNER_PASSWORD_PROPERTY_KEY = "blipsdk.ownerPassword"
    
    public static let USER_NAME_KEY = "blipUserName"
    public static let USER_PHOTO_URI_KEY = "blipUserPhotoUri"
    public static let USER_EXTERNAL_ID_KEY = "blipUserExternalId"
    public static let USER_EXTRAS_KEY = "blipUserExtras"

}
